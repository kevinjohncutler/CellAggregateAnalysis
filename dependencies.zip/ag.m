function [im,im_min,imax] = ag (im,imin,imax,toDouble)
% ag : autogain, it increases the contrast of image im, using imin and imax.
% It subtracts the the minimum from of the image, divides by the max and
% then normalizes to 255.
%
% INPUT : 
%       im : image
%       imin : min value used to set autogained image (default : min of image)
%       imax : max value used to set autogained image (default : max of image)
% OUTPUT :
%       im : autogained image with increased contrast.
%
%
% Copyright (C) 2016 Wiggins Lab 
% Written by Paul Wiggins.
% University of Washington, 2016
% This file is part of SuperSegger.
% 
% SuperSegger is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% SuperSegger is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with SuperSegger.  If not, see <http://www.gnu.org/licenses/>.
if ~exist('toDouble','var') || isempty( toDouble )
    toDouble = false;
end

im = double(im);

im(isinf(im(:))) = nan;

if exist( 'imin', 'var') && ~isempty(  imin )
    im_min = imin;
else
    im_min = min(im(:));
end

if ~exist( 'imax', 'var') || isempty(imax)
    imax = max(im(:));
end

im_max = imax-im_min;

% subtract min
im = im - double(im_min);
im = im./double(im_max);

   % autogain and normalization to uint8
if ~toDouble
    im = uint8(255*im);
end
end