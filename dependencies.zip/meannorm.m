function nim = meannorm(im,m)
%Normalizes the image so that mthe mean is 1/2. This makes scaled 0-1
%images have an altered range, but it is very good for
%comparison/difference images
if ~exist( 'm', 'var' ) || isempty( m )
    m = 0.5;
end

nim = im.*m./mean(im,'all');
end

