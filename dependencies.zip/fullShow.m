function fullShow(varargin)
%show an image that fills the window as much as possible. 
% provide optional color for greyscale images [r g b] 0-1 scale. 
%imlist should be a cell array of greyscale images

args = matlab.images.internal.stringToChar(varargin);
[im,opacity] = parse_inputs(args{:});

    
h = imshow(im,'Border','tight','InitialMagnification','fit');
h.AlphaData = opacity;
axdrag; %added for zoom and pan
end

function [im,opacity] = parse_inputs(im1,varargin)
    %assume im1 is just the first of some number of images
    im = {im1};
    %Assign defaults
    color = [1 1 1];  
    opacity = 1;
    
    for argidx = 1:nargin-1
        if ~isscalar(varargin{argidx}) && ~isvector(varargin{argidx}) && ~ischar(varargin{argidx})
            im = [im; varargin{argidx}];
        elseif ischar(varargin{argidx})
            switch varargin{argidx}
            case 'color'
                color = varargin{argidx+1};
            case 'opacity'
                opacity = varargin{argidx+2};
            end
        end
    end
    
    % at this point we have some list of images
    if numel(im) == 1
        im = im{1}; %let the image be grayscale or rgb as-is 
    else %now there is at least 2
        % need to turn any RGB to gray, and fill in missing channels
        RGBs = cellfun(@(x) numel(size(x))==3,im);
        ind = find(RGBs);
        if ~isempty(ind)
            im{ind} = {rgb2gray(im{ind})}
        end
        if numel(im)<3
            im{3} = zeros(size(im{2}));
        end
        im = cat(3,ag(im{1}).*color(1),ag(im{2}).*color(2),ag(im{3}).*color(3));
    end

    
end