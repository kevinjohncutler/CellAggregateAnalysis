function bw = bwmorphs(varargin)
%this extends bwmorph() to accept multiple filters that it applies in
%succession, left to right. 
args = matlab.images.internal.stringToChar(varargin);
bw = parse_inputs(args{:});
end
function bw = parse_inputs(bw,varargin)
    for argidx = 1:nargin-1
        bw = bwmorph(bw,varargin{argidx});
    end
end

