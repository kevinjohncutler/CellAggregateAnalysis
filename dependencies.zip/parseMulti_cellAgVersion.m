function [metameta, channel_map ] = parseMulti( datadir, tifdir, t_points, xy_points, channels, clean_flag, debug_flag,subfolder_flag)
%% This parses the multichannel raw .tif files in 'datadir' and dumps them
% in 'tifDir' separated into channels and labelled for supersegger.
% t_points must match the original naming format of '01', '02', etc. for now
%% add a flag not to process files but just to get metadata again!!!!!!!!!!!!!
% Output the time by default. (toc is at the end)
tic

%% Handle missing variables 
if ~exist( 'datadir', 'var' ) || isempty( datadir )
    datadir = uigetdir(pwd);
end

if ~exist( 'tifdir', 'var' ) || isempty( tifdir )
    tifdir = uigetdir(pwd);
end

if ~exist( tifdir, 'file' )
    mkdir( tifdir );
end

if ~exist( 't_points', 'var' ) || isempty(t_points)
    disp('Processing all time points');
    t_range_flag = false;
elseif ~isa(t_points,'cell')
    t_range_flag = true;
    for j = 1:length(t_points)
        t_temp{j} =  sprintf( '%02d',t_points(j) );
    end
    t_points = t_temp;
    %for now assuming any char entries will be entered correctly, but
    %that would never be used with this new option
end

if ~exist( 'xy_points', 'var' ) || isempty(xy_points)
    disp('Processing all xy points');
    xy_range_flag = false;
else
    xy_range_flag = true;
end

if ~exist( 'channels', 'var' ) || isempty(channels)
    disp('Processing all channels');
    channel_flag = false;
else
    channel_flag = true;
end

% if ~exist( 'channel_map', 'var' ) || isempty(channel_map)
%     disp('Using default channel map: BF,GFP,mCherry');    
%     channel_map = {{0,'BF'},{1,'GFP'},{2,'mCherry'}};
% end

if ~exist( 'clean_flag', 'var' ) || isempty(clean_flag)
    clean_flag = false;
    
    %should find a way to set clean flag to true if the directory is empty
end

if ~exist( 'debug_flag', 'var' ) || isempty(debug_flag)
    debug_flag = false;
end
if ~exist( 'subfolder_flag', 'var' ) || isempty(subfolder_flag)
    subfolder_flag = false;
end


%% check directories for filesep
%fixes them so that they include it
if datadir(end) ~= filesep
    datadir = [datadir,filesep];
end

if tifdir(end) ~= filesep
    tifdir = [tifdir,filesep];
end

%% Main difference now is that we have to loop through each image and make a reader for each:

imageinfo = getImages(datadir); 

%HERE is wjere we would truncate the imageinfo to be in the range
%(specified by a character)
names = {imageinfo.name};
if t_range_flag
    t_selection  = contains(names,t_points);
else
    t_selection = ones(1,length(names));
end
if xy_range_flag
    xy_selection = contains(names,xy_points);
else
    xy_selection = ones(1,length(names));
end
% if channel_flag
%     c_selection = contains(names,channels);
% else
%     c_selection = ones(1,length(names));
% end
selection = t_selection & xy_selection;
imageinfo = imageinfo(selection);

%the file names of all the images
%number of xy positions no longer can be found from the tifs directly, but
%it is not necessary to know from the start; the specific mapping a1 a2 etc
%from general categories a,b,c etc can be built during this processing.
%In fact, all I am requiring is that each competition be labelled by a
%single letter. The filenames are automatically sorted alphanumerically,
%but we can just build up a list of alphanumeric region labels and their xy
%mappings. DOn't even need to pass in a map - instead, need to passs back a
%map. 

%forcing the xy position to be an alphabetical character, and might as well
%truncate it to the used letters. We are assuming that the 
alphabet = 'abcdefghijklmnopqrstuvwxyz';
%shortcuts  = alphabet(1:length(labels));
extension = '.tif';


for j = 1:length(imageinfo)
    folder = imageinfo(j).folder;
    filename = imageinfo(j).name(1:end-length(extension));
           
    imdir = [folder filesep filename extension];
    reader = bfGetReader(imdir);
    omeMeta = reader.getMetadataStore();
    omeXML = char(omeMeta.dumpXML());
    metadata = xml2struct(omeXML);
    metameta{j} = metadata.OME;
    imsize          = [reader.getSizeX() reader.getSizeY()];
    num_channels    = reader.getSizeC();
    z = 0; %no z stacks as of yet
    base_name = ''; 

    %% Get image, make name, and save while looping
    %[somebasename]t[number]xy[number]c[number].tif
    %no longer need to loop over series or time points in this method
        for c = 0:num_channels - 1
            
            k = c+1;
            channel_name = metadata.OME.Image.Pixels.Channel{1, k}.Attributes.Name;
            channel_map{k} = {k,channel_name}; 
            
            %I think this is still the best way to select for a channel,
            %becasue we can match with either the channel number or the
            %name
            if clean_flag && any(contains(channels,channel_name,'IgnoreCase',true))
                base_name = channel_name; 
                im_name = [filename '_' base_name '_c' num2str(c+1)];
                im = bfGetPlane(reader,reader.getIndex(0,c,0)+1);%t=0 for each file
                imwrite(im,[tifdir im_name '.tif'])
            end
        end

end
if subfolder_flag
    %% make directory structure
    %edit for arbitrarily many channels

    for j = 1:num_channels
        try
            channel_map{j}{3}  = [tifdir channel_map{j}{2} filesep];
            mkdir(channel_map{j}{3});
        catch
            disp('Error making directories');
        end
    end


    %% move files into dir structure

    for j = 1:num_channels 
        try
            [status,message,messageid] = movefile( [tifdir '*c' num2str(channel_map{j}{1}) '*.tif' ], channel_map{j}{3} );
        catch
            disp('Error moving files');
        end
    end


    disp('The file structure is as follows:')
    dir(tifdir)
end
toc
end

