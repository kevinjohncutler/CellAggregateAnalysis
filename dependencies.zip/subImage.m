function subimage = subImage(im,bbx)
%Return the subimage of I given boundingbox 
% assumes that the input is not out of bounds in the top left corner. Does
% correct for any overhang. [left, top, width, height]


[h,w] = size(im);

%check that boundingbox has valid coordinates
bbx(1) = max(bbx(1),1);
bbx(2) = max(bbx(2),1);
bbx(3) = min(bbx(3),w-bbx(1));
bbx(4) = min(bbx(4),h-bbx(2));

subimage(:,:,:) = im(ceil(bbx(2)):floor(bbx(2)+bbx(4)),ceil(bbx(1)):floor(bbx(1)+bbx(3)),:);
end

