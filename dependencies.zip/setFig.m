function fig = setFig(fig,fig_name,fig_idx,aspect_ratio,num_columns,screen_num)
% Tile images

fig_idx = fig_idx-1; %0-based indexing more convenient
if ~exist( 'num_columns', 'var' ) || isempty( num_columns )
    num_columns = 3;
end

if ~exist( 'screen_num', 'var' ) || isempty( screen_num )
    screen_num = 1;
end

set(groot,'units','pixels')
screensize = get(groot,'screensize');
sh = screensize(4);
sw = screensize(3);
% Unique to OS
 
set(groot,'units','normalized')
% imw = sw./num_columns;
% imh = round(aspect_ratio.*imw);
% dx = imw.*(mod(fig_idx,num_columns))+windowborder;
% dy = -(imh+titlebar-windowborder).*(ceil((fig_idx+1)./num_columns));
% 
% %% x and y are the lower left corner. 
% pos = [sw.*(screen_num -1)+dx,sh+dy,imw,imh];
imw = 1/num_columns;
imh = ((aspect_ratio*sw/sh).*imw);
dx = imw.*(mod(fig_idx,num_columns));
dy = 0.7465-1;
pos = [(screen_num -1)+dx,1+dy,imw,imh];
set(fig,'units','normalized','Position',pos,'Name',fig_name,'NumberTitle','off','Visible','on','ToolBar','none','MenuBar', 'none')
end

