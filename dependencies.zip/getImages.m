function baseFileNames = getImages(start_path,imageType)
% Start with a folder and get a list of all images in the folder and its
% subfolders. 

% If the start_path is empty, ask the user to input one. The imageType may
% be 'tif', 'png', or 'jpeg'

% TODO: get add in an option to specify how many images we allow

%% Define allowed image extensions
allowedExtensions = ['tif','png','jpg'];

%% Catch user input errors / define defaults. 
if ~exist( 'start_path', 'var' ) || isempty( start_path )
    topLevelFolder = uigetdir(pwd);
else
    topLevelFolder = start_path;
end

if ~exist( 'imageType', 'var' ) || isempty( imageType )
    extension = 'tif';
elseif ~ismember(lower(imageType), allowedExtensions)
    disp('error: unsupported file type.');
else
    extension = lower(imageType);
end


%% Get list of all subfolders.
allSubFolders = genpath(topLevelFolder);
% Parse into a cell array.
remain = allSubFolders;
listOfFolderNames = {};
while true
	[singleSubFolder, remain] = strtok(remain, ':'); % use ; in windows, apparently : in linux and macOS
	if isempty(singleSubFolder)
		break;
	end
	listOfFolderNames = [listOfFolderNames singleSubFolder];
end
numberOfFolders = length(listOfFolderNames);

%% Process all image files in those folders.
for k = 1 : numberOfFolders
	% Get this folder and print it out.
	thisFolder = listOfFolderNames{k};
	fprintf('Processing folder %s\n', thisFolder);
	
	filePattern = sprintf(['%s/*.' extension], thisFolder);
	baseFileNames = dir(filePattern);
end
end

